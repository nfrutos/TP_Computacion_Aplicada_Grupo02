#!/bin/bash
# backup_full.sh - Script de backup general para el TP
# Uso:
#   backup_full.sh ORIGEN DESTINO
# Ejemplos:
#   backup_full.sh /var/log /backup_dir
#   backup_full.sh /www_dir /backup_dir
#
# Opciones:
#   -help    Muestra esta ayuda y termina.

# ---------- Función de ayuda ----------
mostrar_ayuda() {
    cat <<EOF
Uso: $0 ORIGEN DESTINO

Realiza un backup comprimido (.tar.gz) del directorio ORIGEN
y lo guarda en DESTINO, con nombre que incluye la fecha en formato ANSI (YYYYMMDD).

Ejemplos:
  $0 /var/log   /backup_dir
  $0 /www_dir   /backup_dir

Opciones:
  -help    Muestra esta ayuda y termina.
EOF
}

# ---------- Manejo de -help ----------
if [ "$1" = "-help" ] || [ "$1" = "--help" ]; then
    mostrar_ayuda
    exit 0
fi

# ---------- Validación de cantidad de parámetros ----------
if [ $# -ne 2 ]; then
    echo "Error: se requieren 2 parámetros: ORIGEN y DESTINO."
    echo "Use: $0 -help para ver la ayuda."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# ---------- Validación de existencia de directorios ----------
if [ ! -d "$ORIGEN" ]; then
    echo "Error: el directorio de origen '$ORIGEN' no existe."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: el directorio de destino '$DESTINO' no existe."
    exit 1
fi

# ---------- Validar que estén montados ----------
if ! mountpoint -q "$ORIGEN"; then
    echo "Advertencia: '$ORIGEN' no es un punto de montaje."
    echo "Se realizará el backup igualmente, pero el TP pide verificar los sistemas de archivos."
fi

if ! mountpoint -q "$DESTINO"; then
    echo "Error: '$DESTINO' no es un punto de montaje. No se puede continuar."
    exit 1
fi

# ---------- Construir nombre del archivo ----------
# Usamos el último componente del origen (ej: /var/log -> log)
NOMBRE_ORIGEN="$(basename "$ORIGEN")"

FECHA="$(date +%Y%m%d)"
ARCHIVO="${NOMBRE_ORIGEN}_bkp_${FECHA}.tar.gz"

RUTA_FINAL="${DESTINO}/${ARCHIVO}"

echo "------------------------------------"
echo "Iniciando backup..."
echo "Origen : $ORIGEN"
echo "Destino: $RUTA_FINAL"
echo "Fecha  : $FECHA"
echo "------------------------------------"

# ---------- Ejecutar backup ----------
tar -czf "$RUTA_FINAL" "$ORIGEN"

if [ $? -eq 0 ]; then
    echo "Backup completado correctamente."
    echo "Archivo generado: $RUTA_FINAL"
    exit 0
else
    echo "Error al generar el backup."
    # Por prolijidad, si falló borramos el archivo incompleto
    [ -f "$RUTA_FINAL" ] && rm -f "$RUTA_FINAL"
    exit 2
fi
